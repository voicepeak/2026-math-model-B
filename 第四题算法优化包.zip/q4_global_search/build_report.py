"""Generate the delivery report from observed metrics, never hard-code performance."""
import json,hashlib,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
def main():
    m=json.loads((HERE/'results/comparison_metrics.json').read_text(encoding='utf-8'));cfg=json.loads((HERE/'frozen_config.json').read_text(encoding='utf-8'));h=m['holdout']
    rows=['|集合|场景|目标数/策略|基础版秒/源|候选秒/源|耗时降低|胜出场景|','|---|---:|---:|---:|---:|---:|---:|']
    names={'development':'开发集','holdout':'独立留出集','stress':'定向压力集','all':'全部'}
    for key in names:
        r=m[key];rows.append(f'|{names[key]}|{r["scenarios"]}|{r["sources"]}|{r["baseline_s_per_source"]:.3f}|{r["candidate_s_per_source"]:.3f}|{r["reduction_percent"]:.2f}%|{r["wins"]}/{r["scenarios"]}|')
    stress=['|压力类型|基础版秒/源|候选秒/源|降低|','|---|---:|---:|---:|']
    for k,r in m['stress_groups'].items():stress.append(f'|{k}|{r["baseline_s_per_source"]:.3f}|{r["candidate_s_per_source"]:.3f}|{r["reduction_percent"]:.2f}%|')
    worst=['|seed|基础版|候选|候选−基础 秒/源|','|---|---:|---:|---:|']
    for r in m['worst_holdout_cases']:worst.append(f'|{r["seed"]}|{r["baseline"]:.3f}|{r["candidate"]:.3f}|{r["delta"]:.3f}|')
    report=f'''# 第四题多算法优化结果

冻结候选：**{cfg['selected_development_candidate']}**。完成补跑后的440条本地结果记录均全清；另有一次中断执行未全清，详见下方说明。正式官方模拟器尚未验证。所有提升比例来自相同场景、相同误差场的配对实验。历史五次官方演练仅作问题诊断，未与合成结果混算。

{chr(10).join(rows)}

留出集种子30001–30100，在选定参数后才运行。配对场景bootstrap 4000次，耗时降低的95%区间为 **[{h['paired_bootstrap_95_percent'][0]:.2f}%, {h['paired_bootstrap_95_percent'][1]:.2f}%]**。该区间仅反映本合成分布抽样不确定性，不能外推为官方成绩保证。

**中断与重放记录**：首次全量批次在350条结果保存后，聚簇压力seed106候选执行出现10805.49秒墙钟时长，触发real_time_budget，停止时仅清除9/13。原因尚未确定；相同源码、参数、种子重放只需约1.91秒流水线墙钟时间并清除13/13，虚拟耗时441.696秒/源，符合一次环境停顿的表现，但不能据此确认休眠原因。算法与时间保护均未修改。原失败保存在`results/final_combined.failure.json`，重放在`interrupted_case_replay.json`，原350条记录在`final_combined_before_resume.json`；补跑仅填充90个缺失键，完整保留已通过记录。上表描述补齐后的最终场景集合，不代表所有执行尝试均成功。

## 如何在本机运行

1. 在官方模拟器选择“问题4演练测试”，等待接口就绪。此程序不启动测试，不选择正式测试。
2. 在本目录打开终端，执行（把参数替换成自己的参赛队号）：

```powershell
python run_q4.py --robot-id 你的参赛队号
```

若电脑只有py启动器，可用 `py -3 run_q4.py --robot-id 你的参赛队号`。在线程序只需Python标准库。默认连接127.0.0.1:2026；可用`--url`修改。输出在`windows_results_q4/`，含summary、client.jsonl、trace与清除证书。退出码0表示程序完整完成，2表示错误或预算停止；后一种不能宣称全清。不要使用研究原型`run_robot.py`作为最终入口。

`official_total_sources`保持空值，演练结束后以官方界面的源总数核对清除比例。正式测试加密日志仍须在官方模拟器导出，本程序不会伪造日志或正式案例编码。

## 核心变化与比较范围

- 25点环形定向覆盖：原点、998米内环8点、1838米外环16点。32三角片铺满外环，最大边998米，外环内切半径1802.683米。每个源位于某片内，任意180度发射方向至少看得到一个片顶点。Fraction比较核验固定坐标的边长、面积和外边界。
- 各频道持久保存有界误差楔形交会区域，停靠共享测向；未知频道先批扫，再联合安排定位与覆盖路径。
- 多起点最近邻/2-opt滚动路线。包围圆≤19.9米认证清除；≤60米可做一次光学尝试，只有公开success计清除。收集两次方位后可对当前可行多边形的紧包围矩形作光学扫查；每格≤28×28米，距离覆盖半径<20米。
- no_signal不用于排除第四题位置圆；目标未知总数不参与策略。只有覆盖节点全部完成、已知目标全清，或已清到题定上界16个，才完整停止。

共比较31个配置（含基础版）：最近邻、2-opt、多起点、模拟退火、Held–Karp DP，以及覆盖网格、局部恢复、光学阈值、共享基线、旋转和扫描点替换消融。首轮/第二轮/第三轮分别保留`screening*.json/csv`，失败/未获证布局保留在`layout_search.json`。四个决赛候选使用40个开发场景后按预定加权时间指标选定；冻结后未依留出结果调参。

## 全局最优：已证与未证

对于固定25扫描点、从原点起步、终点自由的行走距离，整数规划＋子回路割得到 **17942.133272974348米**，HiGHS在数值容差内报告primal=dual、gap=0。独立质检检查模型、点集与路径长度；未用独立求解器重求dual。这只是固定点路线的最优性，不覆盖未知源位置、测向、定位绕行或在线决策。

`optimality.py`还精确求解合成真值中心的开放TSP，构造离线乐观下界：L≥max(0,L_center−40N)，T≥L/5+5N。真值只用于离线下界分析。现有最终策略与下界仍有间隙，因此**尚未证明或实现整个第四题在线问题的全局最优**。

## 压力与退化

{chr(10).join(stress)}

下面列出留出集中相对改善最少的10局；正差表示退化，负差仍表示改善：

{chr(10).join(worst)}

留出集候选失败清除{h['candidate_failed_clears']}次，基础版{h['baseline_failed_clears']}次。候选最长本地完整测试流水线墙钟耗时{h['candidate_max_local_wall_s']:.2f}秒（并行离线运行，含初始化与审计，不能视为官方程序耗时）。最终HTTP入口另记录从enter前到exit后的实际程序墙钟耗时。

## 复现与文件

研究图表复现需`requirements-research.txt`依赖。运行：

```powershell
python reproduce.py
```

该命令核对冻结哈希，重跑40开发＋100留出＋80压力的两策略配对，运行私有随机端口HTTP模拟自测，重建结果和9张图并执行严格图审。在线算法不会并发动作；这里只对独立离线场景采用4进程。`python reproduce.py --verify-only`执行缩小重放、重新计算统计与图表并验证保存研究。完整复现可能需数分钟到十余分钟，取决于机器。

- `results/comparison_metrics.json`：汇总与置信区间。
- `results/final_*.csv/json`：全部逐局结果。
- `results/trace_candidate_random_30001.json`：同案例完整轨迹与证书。
- `results/复现清单.json`、`frozen_hashes.json`：运行环境、参数与哈希。
- `figures/`：9张SVG和300dpi PNG，`_qa/`为灰度预览。
- `P1验收记录.md`、`最终验收记录.md`：独立门禁范围和证据；以最终回执为准。

实际读取技能入口：math-modeling、编程手、算法索引与优化说明、Subagent调度、科研可视化工具；官方与接口依据见inputs和模型增量。关键命令与退出码记录在`results/reproduction_log.json`。仅覆盖第四题算法研究，不生成或提交论文。使用指南要求参赛队人工核对与采用，官方测试结果仍待用户执行。
'''
    (HERE/'README.md').write_text(report,encoding='utf-8')
    print('Report written from actual result files.')
if __name__=='__main__':main()
